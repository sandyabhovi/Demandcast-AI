"""Data-drift check + automated retraining trigger.
Schedule it (cron / EventBridge -> Lambda -> EC2):  python -m src.retrain
Replace the CSVs in data/raw/ with fresh data, then this decides whether to retrain."""
import argparse
import json
import numpy as np
from scipy.stats import ks_2samp

from .config import H, OUT
from .data import load_m5


def drift_report(df, recent=H, ref=90, alpha=0.01):
    drifted = []
    for sid, g in df.groupby("id"):
        y = g.sort_values("time_idx").sales.values
        new, old = y[-recent:], y[-(recent + ref):-recent]
        if len(old) < 30:
            continue
        stat, p = ks_2samp(new, old)
        shift = abs(new.mean() - old.mean()) / (old.mean() + 1e-6)
        if p < alpha and shift > 0.25:
            drifted.append(sid)
    share = len(drifted) / max(df.id.nunique(), 1)
    return {"n_series": int(df.id.nunique()), "n_drifted": len(drifted),
            "share_drifted": round(share, 3), "drifted_ids": drifted[:20]}


def main(threshold=0.2, force=False):
    df = load_m5()
    rep = drift_report(df)
    (OUT / "drift_report.json").write_text(json.dumps(rep, indent=2))
    print(rep)
    if force or rep["share_drifted"] >= threshold:
        print("Drift above threshold -> retraining")
        from .run_all import run
        run(["ma", "xgb", "tft"])
    else:
        print("No retraining needed")


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--threshold", type=float, default=0.2)
    ap.add_argument("--force", action="store_true")
    a = ap.parse_args()
    main(a.threshold, a.force)
