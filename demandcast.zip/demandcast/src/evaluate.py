import numpy as np
import pandas as pd


def wmape(y, p):
    y, p = np.asarray(y, float), np.asarray(p, float)
    return float(np.abs(y - p).sum() / max(np.abs(y).sum(), 1e-9))


def mae(y, p):
    return float(np.mean(np.abs(np.asarray(y) - np.asarray(p))))


def rmse(y, p):
    return float(np.sqrt(np.mean((np.asarray(y) - np.asarray(p)) ** 2)))


def score(actual: pd.DataFrame, pred: pd.DataFrame, name: str) -> dict:
    """actual: id,time_idx,sales   pred: id,time_idx,pred"""
    m = actual[["id", "time_idx", "sales"]].merge(
        pred[["id", "time_idx", "pred"]], on=["id", "time_idx"], how="inner")
    return {"model": name, "MAE": mae(m.sales, m.pred), "RMSE": rmse(m.sales, m.pred),
            "WMAPE": wmape(m.sales, m.pred), "n": len(m)}
