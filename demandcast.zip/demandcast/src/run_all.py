"""Run the full pipeline:  python -m src.run_all --models ma,snaive,sarima,xgb,lstm,tft"""
import argparse
import pandas as pd

from .config import H, OUT, STORE, N_ITEMS
from .data import load_m5, split_points
from .features import build_features
from .evaluate import score
from . import baselines


def run(models, store=STORE, n_items=N_ITEMS):
    df = load_m5(store, n_items)
    val_start, test_start, T = split_points(df, H)
    feat = build_features(df)
    actual = df[df.time_idx >= test_start][["id", "time_idx", "sales"]]
    print(f"series={df.id.nunique()}  days={T}  test window=[{test_start},{T - 1}]")

    results, preds = [], {}

    def record(name, p):
        preds[name] = p
        p.to_csv(OUT / f"pred_{name}.csv", index=False)
        results.append(score(actual, p, name))
        print(results[-1])

    if "ma" in models:
        record("ma28", baselines.moving_average(df, test_start))
    if "snaive" in models:
        record("seasonal_naive", baselines.seasonal_naive(df, test_start))
    if "sarima" in models:
        record("sarima", baselines.sarima(df, test_start))
    if "xgb" in models:
        from . import xgb_model, explain
        p, model, Xs = xgb_model.train_predict(feat, val_start, test_start)
        record("xgboost", p)
        try:
            explain.shap_summary(model, Xs)
        except Exception as e:
            print("SHAP skipped:", e)
    if "lstm" in models:
        from . import lstm_model
        record("lstm", lstm_model.train_predict(feat, val_start, test_start))
    if "tft" in models:
        from . import tft_model
        p, _ = tft_model.train_predict(feat, val_start, test_start)
        record("tft", p)
        meta = df[["id", "item_id", "store_id", "time_idx", "date"]]
        fc = p.merge(meta, on=["id", "time_idx"], how="left")
        fc.to_csv(OUT / "tft_forecasts.csv", index=False)

    res = pd.DataFrame(results)
    base = res.loc[res.model == "ma28", "WMAPE"]
    if len(base):
        res["WMAPE_improvement_vs_ma28_%"] = (base.iloc[0] - res.WMAPE) / base.iloc[0] * 100
    res = res.sort_values("WMAPE")
    res.to_csv(OUT / "results.csv", index=False)
    print("\n", res.round(4).to_string(index=False))
    return res


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--models", default="ma,snaive,sarima,xgb,lstm,tft")
    ap.add_argument("--store", default=STORE)
    ap.add_argument("--n_items", type=int, default=N_ITEMS)
    a = ap.parse_args()
    run(a.models.split(","), a.store, a.n_items)
