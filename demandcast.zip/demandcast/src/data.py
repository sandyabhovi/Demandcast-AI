"""Load the M5 dataset (Kaggle: m5-forecasting-accuracy) into a long dataframe.

Put these files in data/raw/:
  sales_train_evaluation.csv, calendar.csv, sell_prices.csv
"""
import pandas as pd
from .config import RAW, STORE, N_ITEMS

ID_COLS = ["id", "item_id", "dept_id", "cat_id", "store_id", "state_id"]


def load_m5(store=STORE, n_items=N_ITEMS) -> pd.DataFrame:
    sales = pd.read_csv(RAW / "sales_train_evaluation.csv")
    cal = pd.read_csv(RAW / "calendar.csv")
    prices = pd.read_csv(RAW / "sell_prices.csv")

    sales = sales[sales.store_id == store].copy()
    day_cols = [c for c in sales.columns if c.startswith("d_")]
    sales["_tot"] = sales[day_cols].sum(axis=1)
    sales = sales.nlargest(n_items, "_tot").drop(columns="_tot")

    df = sales.melt(id_vars=ID_COLS, value_vars=day_cols, var_name="d", value_name="sales")

    cal = cal[["d", "date", "wm_yr_wk", "event_name_1", "event_type_1",
               "snap_CA", "snap_TX", "snap_WI"]]
    df = df.merge(cal, on="d", how="left")
    df = df.merge(prices, on=["store_id", "item_id", "wm_yr_wk"], how="left")

    df["date"] = pd.to_datetime(df["date"])
    df["time_idx"] = df["d"].str[2:].astype(int) - 1
    df["snap"] = 0
    for st in ("CA", "TX", "WI"):
        m = df.state_id == st
        df.loc[m, "snap"] = df.loc[m, f"snap_{st}"]
    df = df.drop(columns=["snap_CA", "snap_TX", "snap_WI", "wm_yr_wk"])

    df = df.sort_values(["id", "time_idx"]).reset_index(drop=True)
    # prices are missing before an item is first sold -> fill within series
    df["sell_price"] = df.groupby("id")["sell_price"].transform(lambda s: s.ffill().bfill())
    df["sell_price"] = df["sell_price"].fillna(df["sell_price"].median())
    df["event_name_1"] = df["event_name_1"].fillna("none").astype(str)
    df["event_type_1"] = df["event_type_1"].fillna("none").astype(str)
    df["sales"] = df["sales"].astype(float)
    return df


def split_points(df: pd.DataFrame, h: int):
    """train: < val_start | val: [val_start, test_start) | test: >= test_start"""
    T = int(df.time_idx.max()) + 1
    return T - 2 * h, T - h, T
