"""SHAP explainability for the tree model (forecast drivers)."""
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import shap

from .config import OUT


def shap_summary(model, X, fname="shap_summary.png", max_rows=2000):
    X = X.sample(min(len(X), max_rows), random_state=0)
    sv = shap.TreeExplainer(model).shap_values(X)
    shap.summary_plot(sv, X, show=False, max_display=15)
    plt.savefig(OUT / fname, bbox_inches="tight", dpi=120)
    plt.close()
    shap.summary_plot(sv, X, plot_type="bar", show=False, max_display=15)
    plt.savefig(OUT / fname.replace(".png", "_bar.png"), bbox_inches="tight", dpi=120)
    plt.close()
    print(f"[SHAP] saved to outputs/{fname}")
