"""Intermediate level: XGBoost on lag/rolling/calendar/price features."""
import numpy as np
import pandas as pd
import xgboost as xgb

from .config import MODELS, SEED
from .features import FEATURES, CAT_COLS


def _prep(df):
    return df[FEATURES].copy()


def train_predict(feat_df, val_start, test_start):
    d = feat_df.copy()
    for c in CAT_COLS:
        d[c] = d[c].astype("category")

    train = d[d.time_idx < val_start].dropna(subset=["lag_28"])
    val = d[(d.time_idx >= val_start) & (d.time_idx < test_start)]
    test = d[d.time_idx >= test_start]

    model = xgb.XGBRegressor(
        n_estimators=1500, learning_rate=0.05, max_depth=7, subsample=0.8,
        colsample_bytree=0.8, min_child_weight=5, objective="reg:tweedie",
        tweedie_variance_power=1.2, enable_categorical=True, tree_method="hist",
        early_stopping_rounds=50, random_state=SEED, n_jobs=-1)
    model.fit(_prep(train), train.sales, eval_set=[(_prep(val), val.sales)], verbose=100)
    model.save_model(str(MODELS / "xgb.json"))

    out = test[["id", "time_idx"]].copy()
    out["pred"] = np.clip(model.predict(_prep(test)), 0, None)
    return out, model, _prep(pd.concat([train.sample(min(len(train), 3000), random_state=SEED), val]))
