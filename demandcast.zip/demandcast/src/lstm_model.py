"""Intermediate level: global LSTM with exogenous (known-future) covariates.
Encoder reads the last L days (sales + covariates); the head sees the encoder state,
an SKU embedding and the covariates for the next H days, and outputs all H days at once."""
import numpy as np
import pandas as pd
import torch
import torch.nn as nn
from torch.utils.data import Dataset, DataLoader

from .config import H, MODELS, SEED

L = 56
COV = ["dow_n", "month_n", "event", "snap", "price_rel"]
dev = "cuda" if torch.cuda.is_available() else "cpu"


class WinDS(Dataset):
    def __init__(self, Ys, C, samples):
        self.Ys, self.C, self.s = Ys, C, samples

    def __len__(self):
        return len(self.s)

    def __getitem__(self, i):
        n, e = self.s[i]
        past = np.concatenate([self.Ys[n, e - L:e, None], self.C[n, e - L:e]], 1)
        return (torch.tensor(past), torch.tensor(self.C[n, e:e + H]),
                torch.tensor(n), torch.tensor(self.Ys[n, e:e + H]))


class Net(nn.Module):
    def __init__(self, n_items, F, hid=64, emb=8):
        super().__init__()
        self.emb = nn.Embedding(n_items, emb)
        self.lstm = nn.LSTM(1 + F, hid, num_layers=2, batch_first=True, dropout=0.1)
        self.head = nn.Sequential(nn.Linear(hid + emb + H * F, 128), nn.ReLU(),
                                  nn.Dropout(0.1), nn.Linear(128, H))

    def forward(self, past, fut, item):
        _, (h, _) = self.lstm(past)
        return self.head(torch.cat([h[-1], self.emb(item), fut.flatten(1)], 1))


def _arrays(df):
    d = df.sort_values(["id", "time_idx"]).copy()
    d["dow_n"] = d["dow"] / 6.0
    d["month_n"] = d["month"] / 12.0
    d["event"] = (d["event_name_1"] != "none").astype(float)
    ids = d["id"].unique()
    N, T = len(ids), d.time_idx.nunique()
    Y = d["sales"].values.reshape(N, T).astype(np.float32)
    C = d[COV].values.reshape(N, T, len(COV)).astype(np.float32)
    return ids, Y, C


def train_predict(feat_df, val_start, test_start, epochs=30, bs=256, lr=2e-3):
    torch.manual_seed(SEED)
    ids, Y, C = _arrays(feat_df)
    N, T = Y.shape
    scale = np.maximum(Y[:, :val_start].mean(1, keepdims=True), 0.1).astype(np.float32)
    Ys = Y / scale

    tr = [(n, e) for n in range(N) for e in range(L, val_start - H + 1, 3)]
    va = [(n, val_start) for n in range(N)]
    tl = DataLoader(WinDS(Ys, C, tr), batch_size=bs, shuffle=True)
    vl = DataLoader(WinDS(Ys, C, va), batch_size=bs)

    net = Net(N, len(COV)).to(dev)
    opt = torch.optim.AdamW(net.parameters(), lr=lr, weight_decay=1e-4)
    lossf = nn.L1Loss()
    best, bad = 1e9, 0
    for ep in range(epochs):
        net.train()
        for past, fut, n, y in tl:
            past, fut, n, y = past.to(dev), fut.to(dev), n.to(dev), y.to(dev)
            opt.zero_grad()
            lossf(net(past, fut, n), y).backward()
            nn.utils.clip_grad_norm_(net.parameters(), 1.0)
            opt.step()
        net.eval()
        with torch.no_grad():
            v = np.mean([lossf(net(a.to(dev), b.to(dev), c.to(dev)), d.to(dev)).item()
                         for a, b, c, d in vl])
        print(f"[LSTM] epoch {ep + 1} val_l1={v:.4f}")
        if v < best:
            best, bad = v, 0
            torch.save(net.state_dict(), MODELS / "lstm.pt")
        else:
            bad += 1
            if bad >= 5:
                break

    net.load_state_dict(torch.load(MODELS / "lstm.pt", map_location=dev))
    net.eval()
    te = [(n, test_start) for n in range(N)]
    preds = []
    with torch.no_grad():
        for past, fut, n, _ in DataLoader(WinDS(Ys, C, te), batch_size=bs):
            preds.append(net(past.to(dev), fut.to(dev), n.to(dev)).cpu().numpy())
    P = np.clip(np.concatenate(preds) * scale, 0, None)
    return pd.DataFrame({"id": np.repeat(ids, H),
                         "time_idx": np.tile(np.arange(test_start, test_start + H), N),
                         "pred": P.reshape(-1)})
