import pandas as pd

from .config import H

# Lags start at H so ONE model can forecast any day of the 28-day window
# directly (no recursive forecasting, no leakage).
LAGS = [H, H + 7, H + 14, H + 28]
ROLL = [7, 28]

CAT_COLS = ["item_id", "dept_id", "cat_id", "event_name_1", "event_type_1"]
NUM_COLS = (
    ["sell_price", "price_rel", "price_chg_7", "snap", "dow", "month", "dom",
     "weekofyear", "is_weekend", "time_idx"]
    + [f"lag_{l}" for l in LAGS]
    + [f"rmean_{w}" for w in ROLL]
    + [f"rstd_{w}" for w in ROLL]
)
FEATURES = CAT_COLS + NUM_COLS


def add_calendar(df):
    d = df["date"].dt
    df["dow"] = d.dayofweek
    df["month"] = d.month
    df["dom"] = d.day
    df["weekofyear"] = d.isocalendar().week.astype(int)
    df["is_weekend"] = (df["dow"] >= 5).astype(int)
    return df


def add_price(df):
    g = df.groupby("id")["sell_price"]
    df["price_rel"] = df["sell_price"] / g.transform("mean")
    df["price_chg_7"] = (df["sell_price"] / g.shift(7) - 1).fillna(0)
    return df


def add_lags(df):
    g = df.groupby("id")["sales"]
    for l in LAGS:
        df[f"lag_{l}"] = g.shift(l)
    base = g.shift(H)
    for w in ROLL:
        r = base.groupby(df["id"]).rolling(w, min_periods=1)
        df[f"rmean_{w}"] = r.mean().reset_index(level=0, drop=True)
        df[f"rstd_{w}"] = r.std().reset_index(level=0, drop=True)
    return df


def build_features(df: pd.DataFrame) -> pd.DataFrame:
    df = df.sort_values(["id", "time_idx"]).reset_index(drop=True).copy()
    df = add_calendar(df)
    df = add_price(df)
    df = add_lags(df)
    return df
