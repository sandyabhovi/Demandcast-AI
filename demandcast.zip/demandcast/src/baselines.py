"""Basic level: moving average (stand-in for the retailer's current system),
seasonal naive, and SARIMA."""
import warnings
import numpy as np
import pandas as pd
from joblib import Parallel, delayed

from .config import H


def _future_idx(test_start):
    return np.arange(test_start, test_start + H)


def moving_average(df, test_start, window=28):
    rows = []
    hist = df[df.time_idx < test_start]
    for sid, g in hist.groupby("id"):
        v = g.sales.values[-window:].mean()
        rows.append(pd.DataFrame({"id": sid, "time_idx": _future_idx(test_start), "pred": v}))
    return pd.concat(rows, ignore_index=True)


def seasonal_naive(df, test_start, season=7):
    rows = []
    hist = df[df.time_idx < test_start]
    for sid, g in hist.groupby("id"):
        last = g.sales.values[-season:]
        pred = np.tile(last, int(np.ceil(H / season)))[:H]
        rows.append(pd.DataFrame({"id": sid, "time_idx": _future_idx(test_start), "pred": pred}))
    return pd.concat(rows, ignore_index=True)


def _fit_sarima(sid, y, test_start):
    from statsmodels.tsa.statespace.sarimax import SARIMAX
    try:
        with warnings.catch_warnings():
            warnings.simplefilter("ignore")
            res = SARIMAX(y, order=(1, 0, 1), seasonal_order=(1, 1, 1, 7),
                          enforce_stationarity=False, enforce_invertibility=False
                          ).fit(disp=False, maxiter=50)
            fc = np.clip(res.forecast(H), 0, None)
    except Exception:
        fc = np.tile(y[-7:], int(np.ceil(H / 7)))[:H]
    return pd.DataFrame({"id": sid, "time_idx": _future_idx(test_start), "pred": fc})


def sarima(df, test_start, lookback=365, n_jobs=-1):
    hist = df[df.time_idx < test_start]
    jobs = [delayed(_fit_sarima)(sid, g.sales.values[-lookback:], test_start)
            for sid, g in hist.groupby("id")]
    return pd.concat(Parallel(n_jobs=n_jobs)(jobs), ignore_index=True)
