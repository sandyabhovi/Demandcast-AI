"""Advanced level: Temporal Fusion Transformer (pytorch-forecasting) with
probabilistic (quantile) output and built-in interpretability."""
import numpy as np
import pandas as pd
import torch
import lightning.pytorch as pl
from lightning.pytorch.callbacks import EarlyStopping, ModelCheckpoint
from pytorch_forecasting import TimeSeriesDataSet, TemporalFusionTransformer
from pytorch_forecasting.data import GroupNormalizer
from pytorch_forecasting.metrics import QuantileLoss

from .config import H, MODELS, OUT, SEED

ENC = 90
QUANTILES = [0.02, 0.1, 0.25, 0.5, 0.75, 0.9, 0.98]


def _prep(df):
    d = df[["id", "item_id", "dept_id", "cat_id", "store_id", "time_idx", "sales",
            "sell_price", "snap", "dow", "month", "event_name_1", "event_type_1"]].copy()
    for c in ["id", "item_id", "dept_id", "cat_id", "store_id", "event_name_1", "event_type_1"]:
        d[c] = d[c].astype(str)
    d["dow"] = d["dow"].astype(str)       # treat as categorical (known)
    d["month"] = d["month"].astype(str)
    d["snap"] = d["snap"].astype(float)
    return d


def train_predict(feat_df, val_start, test_start, epochs=20, bs=128):
    pl.seed_everything(SEED)
    d = _prep(feat_df)

    training = TimeSeriesDataSet(
        d[d.time_idx < val_start],
        time_idx="time_idx", target="sales", group_ids=["id"],
        min_encoder_length=ENC // 2, max_encoder_length=ENC,
        min_prediction_length=1, max_prediction_length=H,
        static_categoricals=["item_id", "dept_id", "cat_id", "store_id"],
        time_varying_known_categoricals=["event_name_1", "event_type_1", "dow", "month"],
        time_varying_known_reals=["time_idx", "sell_price", "snap"],
        time_varying_unknown_reals=["sales"],
        target_normalizer=GroupNormalizer(groups=["id"], transformation="softplus"),
        add_relative_time_idx=True, add_target_scales=True, add_encoder_length=True,
        allow_missing_timesteps=False,
    )
    val_ds = TimeSeriesDataSet.from_dataset(
        training, d[d.time_idx < test_start], predict=True, stop_randomization=True)
    test_ds = TimeSeriesDataSet.from_dataset(training, d, predict=True, stop_randomization=True)

    nw = 2
    train_dl = training.to_dataloader(train=True, batch_size=bs, num_workers=nw)
    val_dl = val_ds.to_dataloader(train=False, batch_size=bs * 2, num_workers=nw)
    test_dl = test_ds.to_dataloader(train=False, batch_size=bs * 2, num_workers=nw)

    tft = TemporalFusionTransformer.from_dataset(
        training, learning_rate=0.03, hidden_size=32, attention_head_size=4,
        dropout=0.1, hidden_continuous_size=16, loss=QuantileLoss(QUANTILES),
        log_interval=-1, reduce_on_plateau_patience=3)
    print(f"[TFT] parameters: {tft.size() / 1e3:.1f}k")

    ckpt = ModelCheckpoint(dirpath=str(MODELS), filename="tft-best", monitor="val_loss", mode="min")
    trainer = pl.Trainer(
        max_epochs=epochs, accelerator="auto", gradient_clip_val=0.1,
        callbacks=[EarlyStopping(monitor="val_loss", patience=4, mode="min"), ckpt],
        enable_progress_bar=True, logger=False)
    trainer.fit(tft, train_dl, val_dl)
    best = TemporalFusionTransformer.load_from_checkpoint(ckpt.best_model_path)

    res = best.predict(test_dl, mode="quantiles", return_index=True)
    q = res.output.cpu().numpy()                         # (N, H, 7)
    idx = res.index.reset_index(drop=True)
    N = len(idx)
    out = pd.DataFrame({
        "id": np.repeat(idx["id"].values, H),
        "time_idx": (idx["time_idx"].values[:, None] + np.arange(H)[None, :]).reshape(-1),
        "p10": np.clip(q[:, :, 1], 0, None).reshape(-1),
        "p50": np.clip(q[:, :, 3], 0, None).reshape(-1),
        "p90": np.clip(q[:, :, 5], 0, None).reshape(-1),
    })
    out["pred"] = out["p50"]

    # interpretability: variable importance + attention (validation window)
    try:
        import matplotlib
        matplotlib.use("Agg")
        raw = best.predict(val_dl, mode="raw", return_x=True)
        interp = best.interpret_output(raw.output, reduction="sum")
        for name, fig in best.plot_interpretation(interp).items():
            fig.savefig(OUT / f"tft_{name}.png", bbox_inches="tight", dpi=120)
        print("[TFT] saved interpretation plots to outputs/")
    except Exception as e:
        print(f"[TFT] interpretation skipped: {e}")
    return out, best
