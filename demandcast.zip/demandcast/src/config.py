from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
RAW = ROOT / "data" / "raw"
OUT = ROOT / "outputs"
MODELS = ROOT / "models"
for p in (RAW, OUT, MODELS):
    p.mkdir(parents=True, exist_ok=True)

H = 28            # forecast horizon (days)
STORE = "CA_1"    # one store to stay within free-tier compute
N_ITEMS = 100     # top-N SKUs by volume
SEED = 42
