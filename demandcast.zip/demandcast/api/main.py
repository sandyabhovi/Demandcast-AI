"""FastAPI service.  Run:  uvicorn api.main:app --host 0.0.0.0 --port 8000
Serves the latest probabilistic (P10/P50/P90) TFT forecasts written by the pipeline."""
import os
from pathlib import Path

import pandas as pd
from fastapi import FastAPI, HTTPException, Query

FORECAST_PATH = Path(os.getenv("FORECAST_PATH", "outputs/tft_forecasts.csv"))
RESULTS_PATH = Path(os.getenv("RESULTS_PATH", "outputs/results.csv"))

app = FastAPI(title="DemandCast", version="1.0")
_cache = {"mtime": 0.0, "df": None}


def _load():
    if not FORECAST_PATH.exists():
        raise HTTPException(503, "No forecasts yet. Run `python -m src.run_all` first.")
    m = FORECAST_PATH.stat().st_mtime
    if m != _cache["mtime"]:           # auto-reload after retraining
        _cache["df"] = pd.read_csv(FORECAST_PATH, parse_dates=["date"])
        _cache["mtime"] = m
    return _cache["df"]


@app.get("/health")
def health():
    return {"status": "ok", "forecasts_available": FORECAST_PATH.exists()}


@app.get("/items")
def items():
    df = _load()
    return sorted(df.item_id.unique().tolist())


@app.get("/forecast")
def forecast(item_id: str, store_id: str, horizon: int = Query(28, ge=1, le=28)):
    df = _load()
    f = df[(df.item_id == item_id) & (df.store_id == store_id)].sort_values("time_idx")
    if f.empty:
        raise HTTPException(404, "item/store not found")
    f = f.head(horizon)
    return {
        "item_id": item_id, "store_id": store_id, "horizon": horizon,
        "forecast": [{"date": r.date.strftime("%Y-%m-%d"), "p10": round(r.p10, 2),
                      "p50": round(r.p50, 2), "p90": round(r.p90, 2)}
                     for r in f.itertuples()],
    }


@app.get("/metrics")
def metrics():
    if not RESULTS_PATH.exists():
        raise HTTPException(503, "results.csv not found")
    return pd.read_csv(RESULTS_PATH).to_dict(orient="records")
