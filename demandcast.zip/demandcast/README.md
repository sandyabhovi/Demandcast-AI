# DemandCast

1. `pip install -r requirements.txt`
2. Download M5 from Kaggle (m5-forecasting-accuracy) and put `sales_train_evaluation.csv`,
   `calendar.csv`, `sell_prices.csv` in `data/raw/`.
3. Quick test: `python -m src.run_all --models ma,snaive,xgb`
4. Full run:  `python -m src.run_all` (use a GPU for the LSTM/TFT: Kaggle or SageMaker Studio Lab)
5. Results: `outputs/results.csv` (WMAPE, MAE, RMSE, improvement vs the 28-day moving-average baseline),
   `outputs/shap_summary*.png`, `outputs/tft_*.png`, `outputs/tft_forecasts.csv`.
6. API: `uvicorn api.main:app --port 8000` -> `/docs`
   Docker: `docker build -t demandcast . && docker run -p 8000:8000 demandcast`
7. Retraining: `python -m src.retrain` (drift check -> retrain). Schedule with cron or EventBridge.

AWS: train on SageMaker Studio Lab (T4), store `outputs/` and `models/` in S3,
run the Docker image on EC2 t2.micro, add CloudWatch alarms on `/health` and the drift report.
